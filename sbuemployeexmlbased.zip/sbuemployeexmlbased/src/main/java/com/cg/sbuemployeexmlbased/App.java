package com.cg.sbuemployeexmlbased;

import com.cg.sbuemployeexmlbased.main.Main;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Main main = new Main();
        main.stratApp();
    }
}
