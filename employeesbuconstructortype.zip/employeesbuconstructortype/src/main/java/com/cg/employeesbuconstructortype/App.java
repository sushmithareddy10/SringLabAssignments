package com.cg.employeesbuconstructortype;

import com.cg.employeesbuconstructortype.main.Main;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       Main main = new Main();
       main.startApp();
    }
}
